package Exercicio2;

public class Main {
	
	public static void main(String [] args) {
		//TransformerString transformer = new TransformerMaiusculo();
		TransformerString transformer = new TransformerMinusculo();
		//TransformerString transformer = new TransformerDuplicado();
		//TransformerString transformer = new TransformerReverter();
		transformer.RealizarTransformerString();
	}
}
