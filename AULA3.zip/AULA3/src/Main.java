
public class Main {

	public static void main(String [] args) {
		
		Ordernar ordena = new QuickSort();{
			int[] v = {1,2,3,4,5,5,6,7,1,2,3,4,44,55,3};
			ordena.ordernar(v);
			for(int i = 0; i < v.length; i++)
				System.out.println("QuickSort: " + v[i]);
			
		}
		
		ordena = new SelectionSort();{
			int[] v = {1,2,3,4,5,5,6,7,1,2,3,4,44,55,3};
			ordena.ordernar(v);
			for(int i = 0; i < v.length; i++)
				System.out.println("SelectionSort: " +v[i]);
			
		}
		
		ordena = new BubbleSort();{
			int[] v = {1,2,3,4,5,5,6,7,1,2,3,4,44,55,3};
			ordena.ordernar(v);
			for(int i = 0; i < v.length; i++)
				System.out.println("BubbleSort: " +v[i]);
			
		}
		
		
		ordena = new InsertionSort();{
		int[] v = {1,2,3,4,5,5,6,7,1,2,3,4,44,55,3};
		ordena.ordernar(v);
		for(int i = 0; i < v.length; i++)
			System.out.println("InsertionSort: " +v[i]);
		
		}
	}
}
