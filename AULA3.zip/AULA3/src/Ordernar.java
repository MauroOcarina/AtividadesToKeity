
public interface Ordernar {

	public int[] ordernar(int v[]);
}
