package Exercicio2;

import javax.swing.JOptionPane;

public class TransformerMaiusculo extends TransformerString {
	private String texto;
	
	@Override
	public void LerString() {
		texto = JOptionPane.showInputDialog("");
	}

	
	@Override
	public void ImprimirString() {
		JOptionPane.showMessageDialog(null,""+ texto);
	}

	@Override
	public void TransformarString() {
		texto = texto.toUpperCase();
		
	}

}
